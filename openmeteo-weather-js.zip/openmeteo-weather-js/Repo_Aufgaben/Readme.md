## Leon Neuhaus
[Aufgaben von Leon Neuhaus](https://github.com/LeonWWImmo/Leon_Neuhaus_450_Testing)

---
## Ajna Kryeziu 
[Aufgaben von Ajna](https://github.com/aj-kry/m-450/blob/main/README.md)

---
## Levin Pamay
[Aufgaben von Levin](https://github.com/Le999vin/M450-Uebungen.git)
